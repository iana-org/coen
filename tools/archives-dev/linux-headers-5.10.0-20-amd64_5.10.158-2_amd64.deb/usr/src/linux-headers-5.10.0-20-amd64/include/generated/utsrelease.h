#define UTS_RELEASE "5.10.0-20-amd64"

#!/usr/bin/perl -w
# This file was preprocessed, do not edit!


package Debconf::Element::Editor::Progress;
use strict;
use base qw(Debconf::Element);



sub start {
}

sub set {
	return 1;
}

sub info {
	return 1;
}

sub stop {
}

1;
